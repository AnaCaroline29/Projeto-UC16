<?php
session_start();

// Verificar se o usuário está logado e é do tipo ADMIN
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query('SELECT * FROM tb_chamados');
    $chamados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="chamados.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, array('ID', 'Data', 'Status'), ';');

    foreach ($chamados as $chamado) {
        fputcsv($output, $chamado, ';');
    }

    fclose($output);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
