<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['quantidade'] as $id_equipamentos => $quantidade) {
        foreach ($_SESSION['equipamentos_requisitados'] as &$equipamento) {
            if ($equipamento['id_equipamentos'] == $id_equipamentos) {
                $equipamento['quantidade'] = $quantidade;
                break;
            }
        }
    }
}

if (!isset($_SESSION['equipamentos_requisitados']) || empty($_SESSION['equipamentos_requisitados'])) {
    header('Location: requisicao_reservas_pass2.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisição de Reservas - Passo 3</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Requisição de Reservas - Passo 3</h2>
        <form action="requisicao_reservas_pass4.php" method="POST">
            <fieldset>
                <legend>3. Datas</legend>
                <div class="form-group">
                    <label for="datareserva">Data de Reserva:</label>
                    <input type="date" id="datareserva" name="datareserva" value="<?= date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="datainiciolocacao">Data de Início da Locação:</label>
                    <input type="date" id="datainiciolocacao" name="datainiciolocacao" value="<?= date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="datafimlocacao">Data de Fim da Locação:</label>
                    <input type="date" id="datafimlocacao" name="datafimlocacao" value="<?= date('Y-m-d'); ?>">
                </div>
            </fieldset>
            <div class="form-group">
                <button type="submit">Avançar</button>
            </div>
        </form>
    </div>
</body>
</html>
