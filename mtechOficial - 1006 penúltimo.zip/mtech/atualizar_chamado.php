<?php
session_start();

// Verificar se o usuário está logado e é do tipo ADMIN
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Método de requisição inválido.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('UPDATE tb_chamados SET datahorafechamento = :datahorafechamento, status = :status, numerodeserie = :numerodeserie, descricaofalha = :descricaofalha, descricaosolucao = :descricaosolucao WHERE id_chamadosmanutencao = :id');

    $stmt->execute([
        'datahorafechamento' => $_POST['datahorafechamento'],
        'status' => $_POST['status'],
        'numerodeserie' => $_POST['numerodeserie'],
        'descricaofalha' => $_POST['descricaofalha'],
        'descricaosolucao' => $_POST['descricaosolucao'],
        'id' => $_POST['id_chamadosmanutencao']
    ]);

    echo 'Chamado atualizado com sucesso!';
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
