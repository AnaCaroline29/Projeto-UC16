<?php
session_start();

// Verificar se o usuário está logado e é do tipo USER
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 2) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar os dados do usuário logado
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
    $stmt->execute(['id' => $_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuário não encontrado.');
    }

    // Adicionar equipamento selecionado à lista de equipamentos
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['incluir_equipamento'])) {
        $equipamento = [
            'id_equipamentos' => $_POST['id_equipamentos'],
            'nome' => $_POST['nome']
        ];
        $_SESSION['equipamento_selecionado'] = $equipamento;
        header('Location: registro_chamados.php');
        exit;
    }

    // Registrar chamado
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_chamado'])) {
        $stmt = $pdo->prepare('INSERT INTO tb_chamados (id_usuarios, id_equipamentos, numerodeserie, datahorafalha, datahorafechamento, status, descricaofalha, descricaosolucao)
                               VALUES (:id_usuarios, :id_equipamentos, :numerodeserie, :datahorafalha, :datahorafechamento, :status, :descricaofalha, :descricaosolucao)');
        $stmt->execute([
            'id_usuarios' => $_SESSION['usuario_id'],
            'id_equipamentos' => $_SESSION['equipamento_selecionado']['id_equipamentos'],
            'numerodeserie' => $_POST['numerodeserie'],
            'datahorafalha' => $_POST['datahorafalha'],
            'datahorafechamento' => $_POST['datahorafechamento'],
            'status' => 'Aberto',
            'descricaofalha' => $_POST['descricaofalha'],
            'descricaosolucao' => ''
        ]);
        unset($_SESSION['equipamento_selecionado']);
        header('Location: sucesso.php');
        exit;
    }

} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Chamado</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <a href="menu.php" class="btn btn-primary mt-3">Voltar</a>
        <h2>Registro de Chamado</h2>
        <form action="registro_chamados.php" method="POST">
            <fieldset>
                <legend>1. Dados do Usuário</legend>
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" class="form-control" value="<?= htmlspecialchars($usuario['nome']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($usuario['email']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="cpf_cnpj">CPF/CNPJ:</label>
                    <input type="text" id="cpf_cnpj" name="cpf_cnpj" class="form-control" value="<?= htmlspecialchars($usuario['cpf_cnpj']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="logradouro">Logradouro:</label>
                    <input type="text" id="logradouro" name="logradouro" class="form-control" value="<?= htmlspecialchars($usuario['logradouro']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="numero">Número:</label>
                    <input type="text" id="numero" name="numero" class="form-control" value="<?= htmlspecialchars($usuario['numero']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="bairro">Bairro:</label>
                    <input type="text" id="bairro" name="bairro" class="form-control" value="<?= htmlspecialchars($usuario['bairro']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="cep">CEP:</label>
                    <input type="text" id="cep" name="cep" class="form-control" value="<?= htmlspecialchars($usuario['cep']); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone:</label>
                    <input type="text" id="telefone" name="telefone" class="form-control" value="<?= htmlspecialchars($usuario['telefone']); ?>" readonly>
                </div>
            </fieldset>

            <fieldset>
                <legend>2. Registro de Falha</legend>
                <div class="form-group">
                    <label for="datahorafalha">Data e Hora da Falha:</label>
                    <input type="text" id="datahorafalha" name="datahorafalha" class="form-control" value="<?= date('Y-m-d H:i:s'); ?>" readonly>
                </div>
                <div class="form-group" style="display:none;">
                    <label for="datahorafechamento">Data e Hora de Fechamento:</label>
                    <input type="text" id="datahorafechamento" name="datahorafechamento" class="form-control" value="<?= date('Y-m-d H:i:s', strtotime('+5 days')); ?>">
                </div>
                <div class="form-group" style="display:none;">
                    <label for="status">Status:</label>
                    <input type="text" id="status" name="status" class="form-control" value="Aberto" readonly>
                </div>
                <div class="form-group">
                    <label for="equipamento">Nome do Equipamento:</label>
                    <div class="input-group">
                        <input type="text" id="equipamento" name="equipamento" class="form-control" value="<?= isset($_SESSION['equipamento_selecionado']) ? htmlspecialchars($_SESSION['equipamento_selecionado']['nome']) : ''; ?>" readonly>
                        <div class="input-group-append">
                            <button type="button" class="btn btn-secondary" data-toggle="modal" data-target="#buscarEquipamentoModal">+</button>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="numerodeserie">Número de Série:</label>
                    <input type="text" id="numerodeserie" name="numerodeserie" class="form-control">
                </div>
                <div class="form-group">
                    <label for="descricaofalha">Descrição da Falha:</label>
                    <textarea id="descricaofalha" name="descricaofalha" class="form-control"></textarea>
                </div>
                <div class="form-group" style="display:none;">
                    <label for="descricaosolucao">Descrição da Solução:</label>
                    <textarea id="descricaosolucao" name="descricaosolucao" class="form-control"></textarea>
                </div>
            </fieldset>

            <div class="form-group">
                <button type="submit" name="enviar_chamado" class="btn btn-primary">Enviar</button>
            </div>
        </form>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="buscarEquipamentoModal" tabindex="-1" role="dialog" aria-labelledby="buscarEquipamentoModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="buscarEquipamentoModalLabel">Buscar Equipamento</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="buscarEquipamentoForm" method="GET" action="buscar_equipamento.php">
                        <div class="form-group">
                            <label for="nomeEquipamento">Nome do Equipamento:</label>
                            <input type="text" id="nomeEquipamento" name="nome" class="form-control">
                        </div>
                        <button type="submit" class="btn btn-primary">Buscar</button>
                    </form>
                    <div id="equipamentosResultados"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $('#buscarEquipamentoForm').submit(function(event) {
            event.preventDefault();
            $.get('buscar_equipamentos.php', $(this).serialize(), function(data) {
                $('#equipamentosResultados').html(data);
            });
        });
    </script>
</body>
</html>
