<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
if ($_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se o ID foi passado
    if (!isset($_GET['id'])) {
        die('ID do tipo de usuário não especificado.');
    }

    // Buscar os dados do tipo de usuário
    $stmt = $pdo->prepare('SELECT * FROM tb_tipousuario WHERE id_tipousuario = :id');
    $stmt->execute(['id' => $_GET['id']]);
    $tipoUsuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tipoUsuario) {
        die('Tipo de usuário não encontrado.');
    }
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Tipo de Usuário</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #0056b3;
        }
        .menu-link {
            display: block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
        }
        .menu-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="menu.php" class="menu-link">Voltar ao Menu</a>
        <h2>Editar Tipo de Usuário</h2>
        <form action="atualiza_tipousuario.php" method="POST">
            <input type="hidden" name="id" value="<?= htmlspecialchars($tipoUsuario['id_tipousuario']); ?>">
            <div class="form-group">
                <label for="tipo_usuario">Tipo de Usuário:</label>
                <input type="text" id="tipo_usuario" name="tipo_usuario" value="<?= htmlspecialchars($tipoUsuario['tipo_usuario']); ?>" required>
            </div>
            <div class="form-group">
                <button type="submit">Atualizar</button>
            </div>
        </form>
    </div>
</body>
</html>
