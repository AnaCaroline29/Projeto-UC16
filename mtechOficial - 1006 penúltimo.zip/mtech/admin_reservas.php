<?php
session_start();

// Verificar se o usuário está logado e é ADMIN
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 1) { // Considerando 1 como o tipo ADMIN
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
    exit;
}

$usuario = $equipamentos = $reserva = $status = "";
$dadosUsuario = $dadosEquipamentos = $dadosDatas = $dadosStatus = "";

// Buscar dados da reserva
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buscar_reserva'])) {
    $id_reserva = $_POST['id_reserva'];

    try {
        // Buscar dados da reserva
        $stmt = $pdo->prepare('SELECT * FROM tb_reservas WHERE id_reservas = :id');
        $stmt->execute(['id' => $id_reserva]);
        $reserva = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($reserva) {
            // Buscar dados do usuário
            $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
            $stmt->execute(['id' => $reserva['id_usuarios']]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            // Buscar equipamentos da reserva
            $stmt = $pdo->prepare('SELECT * FROM tb_descreservas WHERE id_reservas = :id');
            $stmt->execute(['id' => $id_reserva]);
            $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Preparar dados do usuário
            $dadosUsuario = $usuario;

            // Preparar dados dos equipamentos
            $dadosEquipamentos = $equipamentos;

            // Preparar dados das datas
            $dadosDatas = [
                'datareserva' => $reserva['datareserva'],
                'datainiciolocacao' => $reserva['datainiciolocacao'],
                'datafimlocacao' => $reserva['datafimlocacao']
            ];

            // Preparar dados do status
            $status = $reserva['status'];
        } else {
            echo 'Reserva não encontrada.';
        }
    } catch (PDOException $e) {
        echo 'Erro: ' . $e->getMessage();
    }
}

// Atualizar dados da reserva
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_reserva'])) {
    $id_reserva = $_POST['id_reserva'];
    $quantidades = $_POST['quantidade'];
    $datareserva = $_POST['datareserva'];
    $datainiciolocacao = $_POST['datainiciolocacao'];
    $datafimlocacao = $_POST['datafimlocacao'];
    $status = $_POST['status'];
    $proposta = '';

    // Upload da proposta
    if (isset($_FILES['proposta']) && $_FILES['proposta']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        $uploadFile = $uploadDir . basename($_FILES['proposta']['name']);
        if (move_uploaded_file($_FILES['proposta']['tmp_name'], $uploadFile)) {
            $proposta = $uploadFile;
        } else {
            echo 'Erro ao fazer upload do arquivo.';
        }
    }

    try {
        // Atualizar dados da reserva
        $stmt = $pdo->prepare('UPDATE tb_reservas SET datareserva = :datareserva, datainiciolocacao = :datainiciolocacao, datafimlocacao = :datafimlocacao, status = :status, proposta = :proposta WHERE id_reservas = :id');
        $stmt->execute([
            'datareserva' => $datareserva,
            'datainiciolocacao' => $datainiciolocacao,
            'datafimlocacao' => $datafimlocacao,
            'status' => $status,
            'proposta' => $proposta,
            'id' => $id_reserva
        ]);

        // Atualizar quantidades dos equipamentos
        foreach ($quantidades as $id_equipamentos => $quantidade) {
            $stmt = $pdo->prepare('UPDATE tb_descreservas SET quantidade = :quantidade WHERE id_reservas = :id_reserva AND id_equipamentos = :id_equipamentos');
            $stmt->execute([
                'quantidade' => $quantidade,
                'id_reserva' => $id_reserva,
                'id_equipamentos' => $id_equipamentos
            ]);
        }

        header('Location: sucesso.php');
        exit;
    } catch (PDOException $e) {
        echo 'Erro: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Validação de Reservas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <a href="menu.php" class="btn btn-primary mb-4">Voltar ao Menu</a>
        <h2>Admin - Validação de Reservas</h2>
        <form method="POST" action="admin_reservas.php">
            <div class="form-group">
                <label for="id_reserva">ID da Reserva:</label>
                <input type="text" id="id_reserva" name="id_reserva" class="form-control" required>
                <button type="submit" name="buscar_reserva" class="btn btn-primary mt-2">Buscar</button>
            </div>
        </form>

        <?php if ($reserva) : ?>
            <form method="POST" action="admin_reservas.php" enctype="multipart/form-data">
                <input type="hidden" name="id_reserva" value="<?= htmlspecialchars($id_reserva); ?>">
                
                <fieldset>
                    <legend>1. Dados do Usuário</legend>
                    <div class="form-group">
                        <label for="nome">Nome:</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?= htmlspecialchars($dadosUsuario['nome']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($dadosUsuario['email']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="cpf_cnpj">CPF/CNPJ:</label>
                        <input type="text" id="cpf_cnpj" name="cpf_cnpj" class="form-control" value="<?= htmlspecialchars($dadosUsuario['cpf_cnpj']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="logradouro">Logradouro:</label>
                        <input type="text" id="logradouro" name="logradouro" class="form-control" value="<?= htmlspecialchars($dadosUsuario['logradouro']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="numero">Número:</label>
                        <input type="text" id="numero" name="numero" class="form-control" value="<?= htmlspecialchars($dadosUsuario['numero']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="cep">CEP:</label>
                        <input type="text" id="cep" name="cep" class="form-control" value="<?= htmlspecialchars($dadosUsuario['cep']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="bairro">Bairro:</label>
                        <input type="text" id="bairro" name="bairro" class="form-control" value="<?= htmlspecialchars($dadosUsuario['bairro']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="telefone">Telefone:</label>
                        <input type="text" id="telefone" name="telefone" class="form-control" value="<?= htmlspecialchars($dadosUsuario['telefone']); ?>" readonly>
                    </div>
                </fieldset>

                <fieldset>
                    <legend>2. Requisição de Equipamentos</legend>
                    <table class="table" id="equipamentos-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Valor Unitário</th>
                                <th>Quantidade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dadosEquipamentos as $equipamento) : ?>
                                <tr>
                                    <td><?= htmlspecialchars($equipamento['id_equipamentos']); ?></td>
                                    <td><?= htmlspecialchars($equipamento['nome']); ?></td>
                                    <td><?= htmlspecialchars($equipamento['valorunit']); ?></td>
                                    <td><input type="number" name="quantidade[<?= htmlspecialchars($equipamento['id_equipamentos']); ?>]" value="<?= htmlspecialchars($equipamento['quantidade']); ?>"></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </fieldset>

                <fieldset>
                    <legend>3. Datas</legend>
                    <div class="form-group">
                        <label for="datareserva">Data de Reserva:</label>
                        <input type="date" id="datareserva" name="datareserva" class="form-control" value="<?= htmlspecialchars($dadosDatas['datareserva']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="datainiciolocacao">Data de Início da Locação:</label>
                        <input type="date" id="datainiciolocacao" name="datainiciolocacao" class="form-control" value="<?= htmlspecialchars($dadosDatas['datainiciolocacao']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="datafimlocacao">Data de Fim da Locação:</label>
                        <input type="date" id="datafimlocacao" name="datafimlocacao" class="form-control" value="<?= htmlspecialchars($dadosDatas['datafimlocacao']); ?>">
                    </div>
                </fieldset>

                <fieldset>
                    <legend>4. Status Solicitação e Proposta de Locação</legend>
                    <div class="form-group">
                        <label for="status">Status Atual:</label>
                        <select id="status" name="status" class="form-control">
                            <option value="Em análise" <?= $status == 'Em análise' ? 'selected' : ''; ?>>Em análise</option>
                            <option value="Atendido" <?= $status == 'Atendido' ? 'selected' : ''; ?>>Atendido</option>
                            <option value="Não Atendido" <?= $status == 'Não Atendido' ? 'selected' : ''; ?>>Não Atendido</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="proposta">Anexar Proposta:</label>
                        <input type="file" id="proposta" name="proposta" class="form-control-file">
                    </div>
                </fieldset>

                <button type="submit" name="atualizar_reserva" class="btn btn-primary">Atualizar</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
