<?php
session_start();

// Verificar se o usuário está logado e é do tipo ADMIN
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 1) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (!isset($_GET['id_reserva'])) {
        die('ID da reserva não fornecido.');
    }

    $id_reserva = $_GET['id_reserva'];

    // Buscar os detalhes da reserva
    $stmt = $pdo->prepare('SELECT * FROM tb_reservas WHERE id_reservas = :id');
    $stmt->execute(['id' => $id_reserva]);
    $reserva = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$reserva) {
        die('Reserva não encontrada.');
    }

    // Buscar os dados do usuário
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
    $stmt->execute(['id' => $reserva['id_usuarios']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuário não encontrado.');
    }

    // Buscar os detalhes dos equipamentos
    $stmt = $pdo->prepare('SELECT * FROM tb_descreservas WHERE id_reservas = :id');
    $stmt->execute(['id' => $id_reserva]);
    $detalhes = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<div class="container">
    <h4>1. Dados do Usuário</h4>
    <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" class="form-control" value="<?= htmlspecialchars($usuario['nome']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($usuario['email']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="cpf_cnpj">CPF/CNPJ:</label>
        <input type="text" id="cpf_cnpj" name="cpf_cnpj" class="form-control" value="<?= htmlspecialchars($usuario['cpf_cnpj']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="logradouro">Logradouro:</label>
        <input type="text" id="logradouro" name="logradouro" class="form-control" value="<?= htmlspecialchars($usuario['logradouro']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="numero">Número:</label>
        <input type="text" id="numero" name="numero" class="form-control" value="<?= htmlspecialchars($usuario['numero']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="bairro">Bairro:</label>
        <input type="text" id="bairro" name="bairro" class="form-control" value="<?= htmlspecialchars($usuario['bairro']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="cep">CEP:</label>
        <input type="text" id="cep" name="cep" class="form-control" value="<?= htmlspecialchars($usuario['cep']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" class="form-control" value="<?= htmlspecialchars($usuario['telefone']); ?>" readonly>
    </div>

    <h4>2. Requisição de Equipamentos</h4>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Valor Unitário</th>
                <th>Quantidade</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($detalhes as $detalhe): ?>
                <tr>
                    <td><?= htmlspecialchars($detalhe['id_equipamentos']); ?></td>
                    <td><?= htmlspecialchars($detalhe['nome']); ?></td>
                    <td><?= htmlspecialchars($detalhe['valorunit']); ?></td>
                    <td><?= htmlspecialchars($detalhe['quantidade']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h4>3. Datas</h4>
    <div class="form-group">
        <label for="datareserva">Data de Reserva:</label>
        <input type="text" id="datareserva" name="datareserva" class="form-control" value="<?= htmlspecialchars($reserva['datareserva']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="datainiciolocacao">Data de Início da Locação:</label>
        <input type="text" id="datainiciolocacao" name="datainiciolocacao" class="form-control" value="<?= htmlspecialchars($reserva['datainiciolocacao']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="datafimlocacao">Data de Fim da Locação:</label>
        <input type="text" id="datafimlocacao" name="datafimlocacao" class="form-control" value="<?= htmlspecialchars($reserva['datafimlocacao']); ?>" readonly>
    </div>

    <h4>4. Status Solicitação e Proposta de Locação</h4>
    <div class="form-group">
        <label for="status">Status Atual:</label>
        <input type="text" id="status" name="status" class="form-control" value="<?= htmlspecialchars($reserva['status']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="proposta">Anexar Proposta:</label>
        <a href="/mtech/<?= htmlspecialchars($reserva['proposta']); ?>" class="btn btn-primary" download="<?= htmlspecialchars($reserva['proposta']); ?>">Baixar Proposta</a>
    </div>
</div>
