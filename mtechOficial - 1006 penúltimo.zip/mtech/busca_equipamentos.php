<?php
session_start();

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
    exit;
}

$equipamentos = [];

if (isset($_GET['nome'])) {
    $nome = $_GET['nome'];
    $stmt = $pdo->prepare('SELECT * FROM tb_equipamentos WHERE nome LIKE :nome');
    $stmt->execute(['nome' => "%$nome%"]);
    $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Busca de Equipamentos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group button {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #0056b3;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
        .actions button {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .actions button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function incluirEquipamento(id, nome, valorunit) {
            window.opener.receberEquipamento(id, nome, valorunit);
            window.close();
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Busca de Equipamentos</h2>
        <form method="GET" action="busca_equipamentos.php">
            <div class="form-group">
                <label for="nome">Nome do Equipamento:</label>
                <input type="text" id="nome" name="nome">
            </div>
            <div class="form-group">
                <button type="submit">Localizar</button>
            </div>
        </form>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Valor Unitário</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($equipamentos as $equipamento): ?>
                    <tr>
                        <td><?= htmlspecialchars($equipamento['id_equipamentos']); ?></td>
                        <td><?= htmlspecialchars($equipamento['nome']); ?></td>
                        <td><?= htmlspecialchars($equipamento['valorunit']); ?></td>
                        <td>
                            <button type="button" onclick="incluirEquipamento('<?= htmlspecialchars($equipamento['id_equipamentos']); ?>', '<?= htmlspecialchars(addslashes($equipamento['nome'])); ?>', '<?= htmlspecialchars($equipamento['valorunit']); ?>')">Incluir</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
