<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
if ($_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Configuração da conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Preparação da inserção dos dados
    $stmt = $pdo->prepare('INSERT INTO tb_tipousuario (tipo_usuario) VALUES (:tipo_usuario)');
    $stmt->bindParam(':tipo_usuario', $_POST['tipo_usuario']);

    // Execução da query
    $stmt->execute();

    echo "Tipo de usuário cadastrado com sucesso!";
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
