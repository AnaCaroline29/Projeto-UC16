<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar o tipo de usuário
$is_admin = ($_SESSION['tipo_usuario'] == 1);
$is_user = ($_SESSION['tipo_usuario'] == 2); // Considerando 2 como o tipo USER
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Principal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f2f2f2;
            margin: 0;
        }
        .container {
            max-width: 400px;
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #fff;
            border-radius: 10px;
            text-align: center;
            box-sizing: border-box;
            margin: 0 10px;
        }
        .container h2 {
            margin-bottom: 20px;
        }
        .button {
            display: block;
            width: calc(100% - 20px); /* Ajuste para a margem */
            padding: 10px;
            margin: 10px auto; /* Ajuste centralizado */
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .button:hover {
            background-color: #0056b3;
        }
        .logout-button {
            background-color: #dc3545;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Bem-vindo, <?= $is_admin ? 'Admin' : ($is_user ? 'Usuário' : ''); ?></h2>
        <?php if ($is_admin) : ?>
            <a href="visualiza_usuarios.php" class="button">Visualizar Usuários</a>
            <a href="cadastro_usuarios.php" class="button">Cadastrar Usuário</a>
            <a href="visualiza_tipousuario.php" class="button">Visualizar Tipos de Usuário</a>
            <a href="cadastro_tipousuario.php" class="button">Cadastrar Tipo de Usuário</a>
            <a href="visualiza_departamentos.php" class="button">Visualizar Departamentos</a>
            <a href="cadastro_departamentos.php" class="button">Cadastrar Departamento</a>
            <a href="visualiza_equipamentos.php" class="button">Visualizar Equipamentos</a>
            <a href="cadastro_equipamentos.php" class="button">Cadastrar Equipamento</a>
            <a href="admin_verifica_reservas.php" class="button">Verificar Reservas</a>
            <a href="admin_reservas.php" class="button">Validar Reservas</a>
            <a href="admin_chamados.php" class="button">Controle de Chamados</a>
        <?php endif; ?>
        <?php if ($is_user) : ?>
            <a href="requisicao_reservas.php" class="button">Requisição de Reservas</a>
            <a href="user_reservas.php" class="button">Verificar Requisições</a>
            <a href="registro_chamados.php" class="button">Suporte - Equipamentos</a>
        <?php endif; ?>
        <a href="logoff.php" class="button logout-button">Logoff</a>
    </div>
</body>
</html>
