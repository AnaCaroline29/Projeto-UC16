<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é do tipo USER
if ($_SESSION['tipo_usuario'] != 2) { // Considerando 2 como o tipo USER
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar os dados do usuário logado
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
    $stmt->execute(['id' => $_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuário não encontrado.');
    }
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}

// Adicionar equipamento selecionado à lista de requisição
if (!isset($_SESSION['equipamentos_requisitados'])) {
    $_SESSION['equipamentos_requisitados'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adicionar_equipamento'])) {
    $equipamentos_requisitados = $_SESSION['equipamentos_requisitados'];
    $equipamentos_requisitados[] = [
        'id_equipamentos' => $_POST['id_equipamentos'],
        'nome' => $_POST['nome'],
        'valorunit' => $_POST['valorunit'],
        'quantidade' => $_POST['quantidade'],
    ];
    $_SESSION['equipamentos_requisitados'] = $equipamentos_requisitados;
    header('Location: requisicao_reservas_pass2.php');
    exit;
}

// Redirecionar para a próxima página
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['avancar'])) {
    // Atualizar as quantidades no array de sessão
    foreach ($_POST['quantidade'] as $id_equipamentos => $quantidade) {
        foreach ($_SESSION['equipamentos_requisitados'] as &$equipamento) {
            if ($equipamento['id_equipamentos'] == $id_equipamentos) {
                $equipamento['quantidade'] = $quantidade;
                break;
            }
        }
    }
    header('Location: requisicao_reservas_pass4.php');
    exit;
}

$equipamentos = [];
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['nome'])) {
    $nome = $_GET['nome'];
    try {
        $stmt = $pdo->prepare('SELECT * FROM tb_equipamentos WHERE nome LIKE :nome');
        $stmt->execute(['nome' => "%$nome%"]);
        $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo 'Erro: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisição de Reservas - Passo 2</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <a href="menu.php" class="btn btn-primary">Voltar ao Menu</a>
        <h2>Requisição de Reservas - Passo 2</h2>
        <form id="equipamentos-form" action="requisicao_reservas_pass2.php" method="POST">
            <fieldset>
                <legend>2. Requisição de Equipamentos</legend>
                <table class="table" id="equipamentos-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Valor Unit.</th>
                            <th>Quantidade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION['equipamentos_requisitados'] as $equipamento): ?>
                            <tr>
                                <td><?= htmlspecialchars($equipamento['id_equipamentos']); ?></td>
                                <td><?= htmlspecialchars($equipamento['nome']); ?></td>
                                <td><?= htmlspecialchars($equipamento['valorunit']); ?></td>
                                <td><input type="number" name="quantidade[<?= htmlspecialchars($equipamento['id_equipamentos']); ?>]" value="<?= htmlspecialchars($equipamento['quantidade']); ?>"></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#buscaEquipamentosModal">+</button>
            </fieldset>

            <div class="form-group">
                <button type="submit" name="avancar" class="btn btn-primary">Avançar</button>
            </div>
        </form>

        <!-- Modal de Busca de Equipamentos -->
        <div class="modal fade" id="buscaEquipamentosModal" tabindex="-1" role="dialog" aria-labelledby="buscaEquipamentosModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="buscaEquipamentosModalLabel">Busca de Equipamentos</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="GET" action="requisicao_reservas_pass2.php" id="busca-equipamentos-form">
                            <div class="form-group">
                                <label for="nome">Nome do Equipamento:</label>
                                <input type="text" id="nome" name="nome" class="form-control">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Localizar</button>
                            </div>
                        </form>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nome</th>
                                    <th>Valor Unitário</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($equipamentos as $equipamento): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($equipamento['id_equipamentos']); ?></td>
                                        <td><?= htmlspecialchars($equipamento['nome']); ?></td>
                                        <td><?= htmlspecialchars($equipamento['valorunit']); ?></td>
                                        <td>
                                            <form method="POST" action="requisicao_reservas_pass2.php">
                                                <input type="hidden" name="id_equipamentos" value="<?= htmlspecialchars($equipamento['id_equipamentos']); ?>">
                                                <input type="hidden" name="nome" value="<?= htmlspecialchars($equipamento['nome']); ?>">
                                                <input type="hidden" name="valorunit" value="<?= htmlspecialchars($equipamento['valorunit']); ?>">
                                                <input type="hidden" name="quantidade" value="1">
                                                <button type="submit" name="adicionar_equipamento" class="btn btn-success">Incluir</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Adicionar Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function() {
            // Restaurar quantidades do localStorage
            const quantidades = JSON.parse(localStorage.getItem('quantidades') || '{}');
            Object.keys(quantidades).forEach(index => {
                const input = document.querySelector(`input[name="quantidade[${index}]"]`);
                if (input) {
                    input.value = quantidades[index];
                }
            });

            // Atualizar quantidades no localStorage ao alterar
            const inputs = document.querySelectorAll('input[name^="quantidade"]');
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    const index = this.name.match(/\d+/)[0];
                    quantidades[index] = this.value;
                    localStorage.setItem('quantidades', JSON.stringify(quantidades));
                });
            });

            // Manter a janela de busca aberta após localizar
            if (window.location.search.indexOf('nome=') !== -1) {
                $('#buscaEquipamentosModal').modal('show');
            }
        });
    </script>
</body>
</html>

