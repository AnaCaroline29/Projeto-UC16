<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
if ($_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Configuração da conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Preparação da inserção dos dados
    $stmt = $pdo->prepare('INSERT INTO tb_usuarios (nome, email, senha, cpf_cnpj, logradouro, numero, bairro, cep, telefone, id_tipousuario, id_departamentos) VALUES (:nome, :email, :senha, :cpf_cnpj, :logradouro, :numero, :bairro, :cep, :telefone, :id_tipousuario, :id_departamentos)');
    
    // Vinculação dos parâmetros
    $stmt->bindParam(':nome', $_POST['nome']);
    $stmt->bindParam(':email', $_POST['email']);
    $stmt->bindParam(':senha', $_POST['senha']);
    $stmt->bindParam(':cpf_cnpj', $_POST['cpf_cnpj']);
    $stmt->bindParam(':logradouro', $_POST['logradouro']);
    $stmt->bindParam(':numero', $_POST['numero']);
    $stmt->bindParam(':bairro', $_POST['bairro']);
    $stmt->bindParam(':cep', $_POST['cep']);
    $stmt->bindParam(':telefone', $_POST['telefone']);
    $stmt->bindParam(':id_tipousuario', $_POST['id_tipousuario']);
    $stmt->bindParam(':id_departamentos', $_POST['id_departamentos']);

    // Execução da query
    $stmt->execute();

    echo "Usuário cadastrado com sucesso!";
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
