<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $equipamentos = [];
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['nome'])) {
        $nome = $_GET['nome'];
        $stmt = $pdo->prepare('SELECT * FROM tb_equipamentos WHERE nome LIKE :nome');
        $stmt->execute(['nome' => "%$nome%"]);
        $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<?php if (!empty($equipamentos)): ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($equipamentos as $equipamento): ?>
                <tr>
                    <td><?= htmlspecialchars($equipamento['id_equipamentos']); ?></td>
                    <td><?= htmlspecialchars($equipamento['nome']); ?></td>
                    <td>
                        <form method="POST" action="registro_chamados.php">
                            <input type="hidden" name="id_equipamentos" value="<?= htmlspecialchars($equipamento['id_equipamentos']); ?>">
                            <input type="hidden" name="nome" value="<?= htmlspecialchars($equipamento['nome']); ?>">
                            <button type="submit" name="incluir_equipamento" class="btn btn-success">Incluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php elseif (isset($_GET['nome'])): ?>
    <p>Nenhum equipamento encontrado.</p>
<?php endif; ?>
