<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sucesso</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 500px;
            padding: 20px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
        }
        .success-message {
            font-size: 1.2em;
            color: #28a745;
            margin-bottom: 20px;
        }
        .menu-link, .logout-link {
            display: block;
            margin: 10px 0;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
        }
        .menu-link:hover, .logout-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-message">
            Requisição de reserva concluída com sucesso!
        </div>
        <a href="menu.php" class="menu-link">Voltar ao Menu</a>
        <a href="logout.php" class="logout-link">Logout</a>
    </div>
</body>
</html>
