<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
if ($_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Configuração da conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Preparação da atualização dos dados
    $stmt = $pdo->prepare('UPDATE tb_usuarios SET nome = :nome, email = :email, senha = :senha, cpf_cnpj = :cpf_cnpj, logradouro = :logradouro, numero = :numero, bairro = :bairro, cep = :cep, telefone = :telefone, id_tipousuario = :id_tipousuario, id_departamentos = :id_departamentos WHERE id_usuarios = :id');

    // Vinculação dos parâmetros
    $stmt->bindParam(':id', $_POST['id']);
    $stmt->bindParam(':nome', $_POST['nome']);
    $stmt->bindParam(':email', $_POST['email']);
    $stmt->bindParam(':senha', $_POST['senha']);
    $stmt->bindParam(':cpf_cnpj', $_POST['cpf_cnpj']);
    $stmt->bindParam(':logradouro', $_POST['logradouro']);
    $stmt->bindParam(':numero', $_POST['numero']);
    $stmt->bindParam(':bairro', $_POST['bairro']);
    $stmt->bindParam(':cep', $_POST['cep']);
    $stmt->bindParam(':telefone', $_POST['telefone']);
    $stmt->bindParam(':id_tipousuario', $_POST['id_tipousuario']);
    $stmt->bindParam(':id_departamentos', $_POST['id_departamentos']);

    // Execução da query
    $stmt->execute();

    echo "Usuário atualizado com sucesso!";
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
