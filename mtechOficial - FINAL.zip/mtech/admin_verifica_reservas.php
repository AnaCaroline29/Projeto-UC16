<?php
session_start();

// Verificar se o usuário está logado e é do tipo ADMIN
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 1) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statusFilter = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
        $statusFilter = $_POST['status'];
    }

    $query = 'SELECT * FROM tb_reservas';
    if ($statusFilter) {
        $query .= ' WHERE status = :status';
    }

    $stmt = $pdo->prepare($query);
    if ($statusFilter) {
        $stmt->execute(['status' => $statusFilter]);
    } else {
        $stmt->execute();
    }

    $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar Reservas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <a href="menu.php" class="btn btn-primary mb-3">Voltar ao Menu</a>
        <h2 class="mb-4">Verificar Reservas</h2>
        <form method="POST" class="mb-4">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="em_analise" value="Em análise">
                <label class="form-check-label" for="em_analise">Em análise</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="atendido" value="Atendido">
                <label class="form-check-label" for="atendido">Atendido</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="nao_atendido" value="Não Atendido">
                <label class="form-check-label" for="nao_atendido">Não Atendido</label>
            </div>
            <button type="submit" class="btn btn-primary ml-2">Filtrar</button>
            <a href="admin_verifica_reservas.php" class="btn btn-secondary ml-2">Limpar</a>
        </form>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>DATA RESERVA</th>
                    <th>ID</th>
                    <th>STATUS</th>
                    <th>DETALHES</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservas as $reserva): ?>
                    <tr>
                        <td><?= htmlspecialchars($reserva['datareserva']); ?></td>
                        <td><?= htmlspecialchars($reserva['id_reservas']); ?></td>
                        <td><?= htmlspecialchars($reserva['status']); ?></td>
                        <td><button class="btn btn-primary" data-toggle="modal" data-target="#detalhesModal" data-id="<?= $reserva['id_reservas']; ?>">+</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button class="btn btn-success" onclick="exportarCSV()">Exportar CSV</button>
        <button class="btn btn-danger" onclick="gerarPDF()">Gerar PDF</button>
    </div>

    <!-- Modal Detalhes -->
    <div class="modal fade" id="detalhesModal" tabindex="-1" role="dialog" aria-labelledby="detalhesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detalhesModalLabel">Detalhes da Reserva</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Detalhes da reserva serão carregados via AJAX -->
                </div>
            </div>
        </div>
    </div>

    <!-- Adicionar Bootstrap JS e jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.debug.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.12/jspdf.plugin.autotable.min.js"></script>

    <script>
        $('#detalhesModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var reservaId = button.data('id');

            var modal = $(this);
            $.ajax({
                url: 'detalhes_admin_reserva.php',
                type: 'GET',
                data: { id_reserva: reservaId },
                success: function (response) {
                    modal.find('.modal-body').html(response);
                }
            });
        });

        function exportarCSV() {
            var csv = 'DATA RESERVA;ID;STATUS\n';
            $('table tbody tr').each(function() {
                var datareserva = $(this).find('td:eq(0)').text();
                var id = $(this).find('td:eq(1)').text();
                var status = $(this).find('td:eq(2)').text();
                csv += datareserva + ';' + id + ';' + status + '\n';
            });

            var hiddenElement = document.createElement('a');
            hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
            hiddenElement.target = '_blank';
            hiddenElement.download = 'reservas.csv';
            hiddenElement.click();
        }

        function gerarPDF() {
            var doc = new jsPDF();
            doc.autoTable({ html: 'table' });
            doc.save('reservas.pdf');
        }
    </script>
</body>
</html>
