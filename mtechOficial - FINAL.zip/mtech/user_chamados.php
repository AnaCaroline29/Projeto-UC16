<?php
session_start();

// Verificar se o usuário está logado e é do tipo USER
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 2) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $statusFilter = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
        $statusFilter = $_POST['status'];
    }

    $query = 'SELECT * FROM tb_chamados WHERE id_usuarios = :id_usuarios';
    if ($statusFilter) {
        $query .= ' AND status = :status';
    }

    $stmt = $pdo->prepare($query);
    if ($statusFilter) {
        $stmt->execute(['id_usuarios' => $_SESSION['usuario_id'], 'status' => $statusFilter]);
    } else {
        $stmt->execute(['id_usuarios' => $_SESSION['usuario_id']]);
    }

    $chamados = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Chamados de Manutenção</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <a href="menu.php" class="btn btn-primary mb-3">Voltar ao Menu</a>
        <h2>Meus Chamados de Manutenção</h2>
        <form method="POST" class="mb-4">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="aberto" value="Aberto">
                <label class="form-check-label" for="aberto">Aberto</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="em_atendimento" value="Em Atendimento">
                <label class="form-check-label" for="em_atendimento">Em Atendimento</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="encerrado" value="Encerrado">
                <label class="form-check-label" for="encerrado">Encerrado</label>
            </div>
            <button type="submit" class="btn btn-primary ml-2">Filtrar</button>
            <a href="user_chamados.php" class="btn btn-secondary ml-2">Limpar</a>
        </form>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data</th>
                    <th>Status</th>
                    <th>Detalhes</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($chamados as $chamado): ?>
                    <tr>
                        <td><?= htmlspecialchars($chamado['id_chamadosmanutencao']); ?></td>
                        <td><?= htmlspecialchars($chamado['datahorafalha']); ?></td>
                        <td><?= htmlspecialchars($chamado['status']); ?></td>
                        <td><button class="btn btn-info" data-toggle="modal" data-target="#detalhesModal" data-id="<?= $chamado['id_chamadosmanutencao']; ?>">+</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button class="btn btn-success" id="exportCsv">Exportar CSV</button>
        <button class="btn btn-danger" id="generatePdf">Gerar PDF</button>
    </div>

    <!-- Modal Detalhes -->
    <div class="modal fade" id="detalhesModal" tabindex="-1" role="dialog" aria-labelledby="detalhesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detalhesModalLabel">Detalhes do Chamado</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Detalhes do chamado serão carregados via AJAX -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.debug.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.12/jspdf.plugin.autotable.min.js"></script>
    <script>
        $('#detalhesModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var chamadoId = button.data('id');
            var modal = $(this);

            $.ajax({
                url: 'detalhes_chamado_user.php',
                type: 'GET',
                data: { id_chamadosmanutencao: chamadoId },
                success: function (response) {
                    modal.find('.modal-body').html(response);
                }
            });
        });

        $('#exportCsv').click(function() {
            var csv = 'ID;DATA;STATUS\n';
            $('table tbody tr').each(function() {
                var id = $(this).find('td:eq(0)').text();
                var data = $(this).find('td:eq(1)').text();
                var status = $(this).find('td:eq(2)').text();
                csv += id + ';' + data + ';' + status + '\n';
            });

            var hiddenElement = document.createElement('a');
            hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
            hiddenElement.target = '_blank';
            hiddenElement.download = 'chamados.csv';
            hiddenElement.click();
        });

        $('#generatePdf').click(function() {
            var doc = new jsPDF();
            doc.autoTable({ html: 'table' });
            doc.save('chamados.pdf');
        });
    </script>
</body>
</html>
