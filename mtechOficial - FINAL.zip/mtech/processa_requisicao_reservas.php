<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Obter o id_usuarios da sessão
    $id_usuarios = $_SESSION['usuario_id'];

    // Gerar um id_descreservas único
    $id_descreservas = uniqid();

    // Preparar e executar a inserção na tabela tb_reservas
    $stmt = $pdo->prepare('INSERT INTO tb_reservas (id_usuarios, datareserva, datainiciolocacao, datafimlocacao, status, id_descreservas) VALUES (:id_usuarios, :datareserva, :datainiciolocacao, :datafimlocacao, :status, :id_descreservas)');
    $stmt->execute([
        ':id_usuarios' => $id_usuarios,
        ':datareserva' => $_POST['datareserva'],
        ':datainiciolocacao' => $_POST['datainiciolocacao'],
        ':datafimlocacao' => $_POST['datafimlocacao'],
        ':status' => 'Em análise',
        ':id_descreservas' => $id_descreservas
    ]);

    // Obter o id_reservas recém-criado
    $id_reservas = $pdo->lastInsertId();

    // Preparar a inserção na tabela tb_descreservas
    $stmt = $pdo->prepare('INSERT INTO tb_descreservas (id_reservas, id_equipamentos, nome, valorunit, quantidade) VALUES (:id_reservas, :id_equipamentos, :nome, :valorunit, :quantidade)');

    // Inserir cada equipamento requisitado na tabela tb_descreservas
    foreach ($_SESSION['equipamentos_requisitados'] as $equipamento) {
        $stmt->execute([
            ':id_reservas' => $id_reservas,
            ':id_equipamentos' => $equipamento['id_equipamentos'],
            ':nome' => $equipamento['nome'],
            ':valorunit' => $equipamento['valorunit'],
            ':quantidade' => $equipamento['quantidade']
        ]);
    }

    // Limpar a sessão de equipamentos requisitados
    unset($_SESSION['equipamentos_requisitados']);

    // Redirecionar para a página de sucesso
    header('Location: sucesso.php');
    exit;

} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
