<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
$is_admin = ($_SESSION['tipo_usuario'] == 1);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
        .actions button {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .actions button:hover {
            background-color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
        .add-button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .add-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Usuários Cadastrados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipo de Usuário</th>
                    <th>Departamento</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Conexão com o banco de dados
                $dsn = 'mysql:host=localhost;dbname=mtech';
                $username = 'root';
                $password = '';

                try {
                    $pdo = new PDO($dsn, $username, $password);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    // Buscar todos os usuários
                    $stmt = $pdo->query('SELECT u.id_usuarios, u.nome, u.email, t.tipo_usuario, d.nome AS departamento
                                         FROM tb_usuarios u
                                         JOIN tb_tipousuario t ON u.id_tipousuario = t.id_tipousuario
                                         JOIN tb_departamentos d ON u.id_departamentos = d.id_departamentos');
                    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($usuarios as $usuario) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($usuario['id_usuarios']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['nome']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['email']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['tipo_usuario']) . '</td>';
                        echo '<td>' . htmlspecialchars($usuario['departamento']) . '</td>';
                        echo '<td>';
                        echo '<div class="actions">';
                        if ($is_admin) {
                            echo '<button onclick="window.location.href=\'edita_usuarios.php?id=' . $usuario['id_usuarios'] . '\'">Editar</button>';
                            echo '<button class="delete-button" onclick="window.location.href=\'exclui_usuarios.php?id=' . $usuario['id_usuarios'] . '\'">Excluir</button>';
                        }
                        echo '</div>';
                        echo '</td>';
                        echo '</tr>';
                    }
                } catch (PDOException $e) {
                    echo 'Erro: ' . $e->getMessage();
                }
                ?>
            </tbody>
        </table>
        <?php if ($is_admin) : ?>
            <button class="add-button" onclick="window.location.href='cadastro_usuarios.php'">Cadastrar Novo Usuário</button>
        <?php endif; ?>
    </div>
</body>
</html>
