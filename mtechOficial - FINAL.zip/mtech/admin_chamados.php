<?php
session_start();

// Verificar se o usuário está logado e é do tipo ADMIN
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 1) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Filtro de status
    $statusFiltro = isset($_GET['status']) ? $_GET['status'] : '';

    // Buscar os chamados
    if ($statusFiltro) {
        $stmt = $pdo->prepare('SELECT * FROM tb_chamados WHERE status = :status');
        $stmt->execute(['status' => $statusFiltro]);
    } else {
        $stmt = $pdo->query('SELECT * FROM tb_chamados');
    }
    $chamados = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Chamados de Manutenção</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <a href="menu.php" class="btn btn-primary mb-3">Voltar</a>
        <h2>Chamados de Manutenção</h2>
        <form method="GET" action="admin_chamados.php" class="mb-3">
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="aberto" value="Aberto" <?= $statusFiltro == 'Aberto' ? 'checked' : '' ?>>
                <label class="form-check-label" for="aberto">Aberto</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="em_atendimento" value="Em Atendimento" <?= $statusFiltro == 'Em Atendimento' ? 'checked' : '' ?>>
                <label class="form-check-label" for="em_atendimento">Em Atendimento</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="encerrado" value="Encerrado" <?= $statusFiltro == 'Encerrado' ? 'checked' : '' ?>>
                <label class="form-check-label" for="encerrado">Encerrado</label>
            </div>
            <button type="submit" class="btn btn-primary ml-2">Filtrar</button>
            <a href="admin_chamados.php" class="btn btn-secondary ml-2">Limpar</a>
        </form>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data</th>
                    <th>Status</th>
                    <th>Detalhes</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($chamados as $chamado): ?>
                    <tr>
                        <td><?= htmlspecialchars($chamado['id_chamadosmanutencao']); ?></td>
                        <td><?= htmlspecialchars($chamado['datahorafalha']); ?></td>
                        <td><?= htmlspecialchars($chamado['status']); ?></td>
                        <td><button type="button" class="btn btn-info" data-toggle="modal" data-target="#detalhesModal" data-id="<?= $chamado['id_chamadosmanutencao']; ?>">+</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <button class="btn btn-success" id="exportCsv">Exportar CSV</button>
        <button class="btn btn-danger" id="generatePdf">Gerar PDF</button>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="detalhesModal" tabindex="-1" role="dialog" aria-labelledby="detalhesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detalhesModalLabel">Detalhes do Chamado</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Detalhes do chamado serão carregados via AJAX -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-primary" id="atualizarChamado">Atualizar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.debug.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.12/jspdf.plugin.autotable.min.js"></script>
    
    <script>
        $('#detalhesModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);

            $.ajax({
                url: 'detalhes_chamado.php',
                type: 'GET',
                data: { id_chamadosmanutencao: id },
                success: function(response) {
                    modal.find('.modal-body').html(response);
                }
            });
        });

        $('#atualizarChamado').click(function() {
            var form = $('#detalhesForm');
            $.ajax({
                url: 'atualizar_chamado.php',
                type: 'POST',
                data: form.serialize(),
                success: function(response) {
                    $('#detalhesModal').modal('hide');
                    location.reload();
                }
            });
        });

        $('#exportCsv').click(function() {
            window.location.href = 'exportar_csv.php';
        });

        $('#generatePdf').click(function() {
            var doc = new jsPDF();
            doc.autoTable({ html: 'table' });
            doc.save('chamados.pdf');

            //window.location.href = 'gerar_pdf.php';
        });
    </script>
</body>
</html>
