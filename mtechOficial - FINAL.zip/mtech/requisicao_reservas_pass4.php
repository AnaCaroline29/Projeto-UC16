<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é do tipo USER
if ($_SESSION['tipo_usuario'] != 2) { // Considerando 2 como o tipo USER
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar os dados do usuário logado
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
    $stmt->execute(['id' => $_SESSION['usuario_id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuário não encontrado.');
    }
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisição de Reservas - Passo 4</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #218838;
        }
        .menu-link {
            display: block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
        }
        .menu-link:hover {
            background-color: #0056b3;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
        .actions button {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .actions button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="menu.php" class="menu-link">Voltar ao Menu</a>
        <h2>Requisição de Reservas - Passo 4</h2>
        <form action="processa_requisicao_reservas.php" method="POST">
            <fieldset>
                <legend>3. Datas</legend>
                <div class="form-group">
                    <label for="datareserva">Data de Reserva:</label>
                    <input type="date" id="datareserva" name="datareserva" value="<?= date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="datainiciolocacao">Data de Início da Locação:</label>
                    <input type="date" id="datainiciolocacao" name="datainiciolocacao" value="<?= date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="datafimlocacao">Data de Fim da Locação:</label>
                    <input type="date" id="datafimlocacao" name="datafimlocacao" value="<?= date('Y-m-d'); ?>">
                </div>
            </fieldset>

            <fieldset>
                <legend>4. Status da Solicitação</legend>
                <div class="form-group">
                    <label for="status">Status Atual:</label>
                    <input type="text" id="status" name="status" value="Em análise" readonly>
                </div>
                <div class="form-group">
                    <label for="proposta">Proposta:</label>
                    <input type="text" id="proposta" name="proposta" readonly>
                </div>
            </fieldset>

            <div class="form-group">
                <button type="submit" name="gravar">Gravar</button>
            </div>
        </form>
    </div>
</body>
</html>
