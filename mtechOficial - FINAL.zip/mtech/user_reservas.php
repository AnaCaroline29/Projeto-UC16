<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar as reservas do usuário logado
    $stmt = $pdo->prepare('SELECT * FROM tb_reservas WHERE id_usuarios = :id');
    $stmt->execute(['id' => $_SESSION['usuario_id']]);
    $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}

// Função para filtrar reservas por status
function filtrarReservas($reservas, $status) {
    return array_filter($reservas, function($reserva) use ($status) {
        return $reserva['status'] === $status;
    });
}

// Filtrar reservas com base no status selecionado
$statusFiltro = isset($_GET['status']) ? $_GET['status'] : '';
$reservasFiltradas = $statusFiltro ? filtrarReservas($reservas, $statusFiltro) : $reservas;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Reservas</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #218838;
        }
        .btn-primary, .btn-success, .btn-danger {
            margin-right: 10px;
        }
        .table thead th {
            text-align: center;
        }
        .table tbody td {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Minhas Reservas</h2>
        <div class="form-group">
            <a href="menu.php" class="btn btn-primary">Voltar ao Menu</a>
        </div>
        <div class="form-group">
            <form method="GET" action="user_reservas.php">
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" id="emAnalise" value="Em análise" <?= $statusFiltro === 'Em análise' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="emAnalise">Em análise</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" id="atendido" value="Atendido" <?= $statusFiltro === 'Atendido' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="atendido">Atendido</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="status" id="naoAtendido" value="Não Atendido" <?= $statusFiltro === 'Não Atendido' ? 'checked' : '' ?>>
                    <label class="form-check-label" for="naoAtendido">Não Atendido</label>
                </div>
                <button type="submit" class="btn btn-primary">Filtrar</button>
                <a href="user_reservas.php" class="btn btn-secondary">Limpar</a>
            </form>
        </div>
        <div class="form-group">
            <button class="btn btn-success" onclick="exportarCSV()">Exportar CSV</button>
            <button class="btn btn-danger" onclick="gerarPDF()">Gerar PDF</button>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>DATA RESERVA</th>
                    <th>ID</th>
                    <th>STATUS</th>
                    <th>DETALHES</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reservasFiltradas as $reserva): ?>
                    <tr>
                        <td><?= htmlspecialchars($reserva['datareserva']); ?></td>
                        <td><?= htmlspecialchars($reserva['id_reservas']); ?></td>
                        <td><?= htmlspecialchars($reserva['status']); ?></td>
                        <td><button class="btn btn-info" onclick="mostrarDetalhes(<?= $reserva['id_reservas']; ?>)">+</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal Detalhes -->
    <div class="modal fade" id="detalhesModal" tabindex="-1" role="dialog" aria-labelledby="detalhesModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="detalhesModalLabel">Detalhes da Reserva</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="detalhesConteudo"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Adicionar Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        function mostrarDetalhes(id_reservas) {
            $.ajax({
                url: 'detalhes_reserva.php',
                type: 'GET',
                data: { id_reservas: id_reservas },
                success: function(data) {
                    $('#detalhesConteudo').html(data);
                    $('#detalhesModal').modal('show');
                },
                error: function() {
                    alert('Erro ao buscar detalhes da reserva.');
                }
            });
        }

        function exportarCSV() {
            const rows = Array.from(document.querySelectorAll('table tr'));
            const csvContent = rows.map(row => {
                const cols = row.querySelectorAll('td, th');
                return Array.from(cols).map(col => `"${col.textContent}"`).join(';');
            }).join('\n');

            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.setAttribute('download', 'reservas.csv');
            link.click();
        }

        function gerarPDF() {
            window.print();
        }
    </script>
</body>
</html>
