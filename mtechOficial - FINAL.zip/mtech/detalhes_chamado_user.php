<?php
session_start();

// Verificar se o usuário está logado e é do tipo USER
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] != 2) {
    die('Acesso negado.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (!isset($_GET['id_chamadosmanutencao'])) {
        die('ID do chamado não fornecido.');
    }

    $id_chamadosmanutencao = $_GET['id_chamadosmanutencao'];

    // Buscar os detalhes do chamado
    $stmt = $pdo->prepare('SELECT * FROM tb_chamados WHERE id_chamadosmanutencao = :id AND id_usuarios = :id_usuarios');
    $stmt->execute(['id' => $id_chamadosmanutencao, 'id_usuarios' => $_SESSION['usuario_id']]);
    $chamado = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$chamado) {
        die('Chamado não encontrado.');
    }

    // Buscar os dados do usuário
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
    $stmt->execute(['id' => $chamado['id_usuarios']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuário não encontrado.');
    }

    // Buscar o nome do equipamento
    $stmt = $pdo->prepare('SELECT nome FROM tb_equipamentos WHERE id_equipamentos = :id');
    $stmt->execute(['id' => $chamado['id_equipamentos']]);
    $equipamento = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<div class="container">
    <h4>1. Dados do Usuário</h4>
    <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" class="form-control" value="<?= htmlspecialchars($usuario['nome']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" class="form-control" value="<?= htmlspecialchars($usuario['email']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="cpf_cnpj">CPF/CNPJ:</label>
        <input type="text" id="cpf_cnpj" name="cpf_cnpj" class="form-control" value="<?= htmlspecialchars($usuario['cpf_cnpj']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="logradouro">Logradouro:</label>
        <input type="text" id="logradouro" name="logradouro" class="form-control" value="<?= htmlspecialchars($usuario['logradouro']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="numero">Número:</label>
        <input type="text" id="numero" name="numero" class="form-control" value="<?= htmlspecialchars($usuario['numero']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="bairro">Bairro:</label>
        <input type="text" id="bairro" name="bairro" class="form-control" value="<?= htmlspecialchars($usuario['bairro']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="cep">CEP:</label>
        <input type="text" id="cep" name="cep" class="form-control" value="<?= htmlspecialchars($usuario['cep']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone" class="form-control" value="<?= htmlspecialchars($usuario['telefone']); ?>" readonly>
    </div>

    <h4>2. Registro Falha</h4>
    <div class="form-group">
        <label for="datahorafalha">Data/Hora da Falha:</label>
        <input type="text" id="datahorafalha" name="datahorafalha" class="form-control" value="<?= htmlspecialchars($chamado['datahorafalha']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="datahorafechamento">Data/Hora de Fechamento:</label>
        <input type="text" id="datahorafechamento" name="datahorafechamento" class="form-control" value="<?= htmlspecialchars($chamado['datahorafechamento']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="status">Status:</label>
        <input type="text" id="status" name="status" class="form-control" value="<?= htmlspecialchars($chamado['status']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="nome_equipamento">Nome do Equipamento:</label>
        <input type="text" id="nome_equipamento" name="nome_equipamento" class="form-control" value="<?= htmlspecialchars($equipamento['nome']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="numerodeserie">Número de Série:</label>
        <input type="text" id="numerodeserie" name="numerodeserie" class="form-control" value="<?= htmlspecialchars($chamado['Numerodeserie']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="descricaofalha">Descrição da Falha:</label>
        <textarea id="descricaofalha" name="descricaofalha" class="form-control" readonly><?= htmlspecialchars($chamado['descricaofalha']); ?></textarea>
    </div>
    <div class="form-group">
        <label for="descricaosolucao">Descrição da Solução:</label>
        <textarea id="descricaosolucao" name="descricaosolucao" class="form-control" readonly><?= htmlspecialchars($chamado['descricaosolucao']); ?></textarea>
    </div>
</div>
