<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar o tipo de usuário
$is_admin = ($_SESSION['tipo_usuario'] == 1);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualização de Departamentos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions {
            display: flex;
            gap: 10px;
        }
        .actions button {
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .actions button:hover {
            background-color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
        .add-button {
            padding: 10px 20px;
            background-color: #28a745;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .add-button:hover {
            background-color: #218838;
        }
        .menu-link {
            display: block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
        }
        .menu-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="menu.php" class="menu-link">Voltar ao Menu</a>
        <h2>Departamentos Cadastrados</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Conexão com o banco de dados
                $dsn = 'mysql:host=localhost;dbname=mtech';
                $username = 'root';
                $password = '';

                try {
                    $pdo = new PDO($dsn, $username, $password);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                    // Buscar todos os departamentos
                    $stmt = $pdo->query('SELECT id_departamentos, nome FROM tb_departamentos');
                    $departamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($departamentos as $departamento) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($departamento['id_departamentos']) . '</td>';
                        echo '<td>' . htmlspecialchars($departamento['nome']) . '</td>';
                        echo '<td>';
                        echo '<div class="actions">';
                        if ($is_admin) {
                            echo '<button onclick="window.location.href=\'edita_departamentos.php?id=' . $departamento['id_departamentos'] . '\'">Editar</button>';
                            echo '<button class="delete-button" onclick="window.location.href=\'exclui_departamentos.php?id=' . $departamento['id_departamentos'] . '\'">Excluir</button>';
                        }
                        echo '</div>';
                        echo '</td>';
                        echo '</tr>';
                    }
                } catch (PDOException $e) {
                    echo 'Erro: ' . $e->getMessage();
                }
                ?>
            </tbody>
        </table>
        <?php if ($is_admin) : ?>
            <button class="add-button" onclick="window.location.href='cadastro_departamentos.php'">Cadastrar Novo Departamento</button>
        <?php endif; ?>
    </div>
</body>
</html>
