<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
if ($_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se o ID foi passado
    if (!isset($_GET['id'])) {
        die('ID do usuário não especificado.');
    }

    // Buscar os dados do usuário
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id');
    $stmt->execute(['id' => $_GET['id']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        die('Usuário não encontrado.');
    }

    // Buscar os tipos de usuário
    $tiposUsuarioStmt = $pdo->query('SELECT id_tipousuario, tipo_usuario FROM tb_tipousuario');
    $tiposUsuario = $tiposUsuarioStmt->fetchAll(PDO::FETCH_ASSOC);

    // Buscar os departamentos
    $departamentosStmt = $pdo->query('SELECT id_departamentos, nome FROM tb_departamentos');
    $departamentos = $departamentosStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        .form-group button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .form-group button:hover {
            background-color: #0056b3;
        }
        .menu-link {
            display: block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            text-align: center;
            border-radius: 5px;
        }
        .menu-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="menu.php" class="menu-link">Voltar ao Menu</a>
        <h2>Editar Usuário</h2>
        <form action="atualiza_usuarios.php" method="POST">
            <input type="hidden" name="id" value="<?= htmlspecialchars($usuario['id_usuarios']); ?>">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($usuario['nome']); ?>" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($usuario['email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" value="<?= htmlspecialchars($usuario['senha']); ?>" required>
            </div>
            <div class="form-group">
                <label for="cpf_cnpj">CPF/CNPJ:</label>
                <input type="text" id="cpf_cnpj" name="cpf_cnpj" value="<?= htmlspecialchars($usuario['cpf_cnpj']); ?>" required>
            </div>
            <div class="form-group">
                <label for="logradouro">Logradouro:</label>
                <input type="text" id="logradouro" name="logradouro" value="<?= htmlspecialchars($usuario['logradouro']); ?>" required>
            </div>
            <div class="form-group">
                <label for="numero">Número:</label>
                <input type="text" id="numero" name="numero" value="<?= htmlspecialchars($usuario['numero']); ?>" required>
            </div>
            <div class="form-group">
                <label for="bairro">Bairro:</label>
                <input type="text" id="bairro" name="bairro" value="<?= htmlspecialchars($usuario['bairro']); ?>" required>
            </div>
            <div class="form-group">
                <label for="cep">CEP:</label>
                <input type="text" id="cep" name="cep" value="<?= htmlspecialchars($usuario['cep']); ?>" required>
            </div>
            <div class="form-group">
                <label for="telefone">Telefone:</label>
                <input type="text" id="telefone" name="telefone" value="<?= htmlspecialchars($usuario['telefone']); ?>" required>
            </div>
            <div class="form-group">
                <label for="id_tipousuario">Tipo de Usuário:</label>
                <select id="id_tipousuario" name="id_tipousuario" required>
                    <?php foreach ($tiposUsuario as $tipo) : ?>
                        <option value="<?= $tipo['id_tipousuario']; ?>" <?= $tipo['id_tipousuario'] == $usuario['id_tipousuario'] ? 'selected' : ''; ?>><?= $tipo['tipo_usuario']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_departamentos">Departamento:</label>
                <select id="id_departamentos" name="id_departamentos" required>
                    <?php foreach ($departamentos as $departamento) : ?>
                        <option value="<?= $departamento['id_departamentos']; ?>" <?= $departamento['id_departamentos'] == $usuario['id_departamentos'] ? 'selected' : ''; ?>><?= $departamento['nome']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit">Atualizar</button>
            </div>
        </form>
    </div>
</body>
</html>

