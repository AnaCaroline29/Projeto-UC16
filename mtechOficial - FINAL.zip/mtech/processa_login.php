<?php
session_start();

// Configuração da conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se os campos foram preenchidos
    if (!isset($_POST['email']) || !isset($_POST['senha'])) {
        die('Por favor, preencha todos os campos.');
    }

    // Buscar o usuário no banco de dados
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE email = :email AND senha = :senha');
    $stmt->execute(['email' => $_POST['email'], 'senha' => $_POST['senha']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        $_SESSION['usuario_id'] = $usuario['id_usuarios'];
        $_SESSION['tipo_usuario'] = $usuario['id_tipousuario'];
        header('Location: menu.php');
        exit;
    } else {
        echo 'Email ou senha incorretos.';
    }
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>

