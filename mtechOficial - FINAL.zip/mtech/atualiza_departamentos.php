<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verificar se o usuário é admin
if ($_SESSION['tipo_usuario'] != 1) {
    die('Acesso negado: você não tem permissão para acessar esta página.');
}

// Configuração da conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Preparação da atualização dos dados
    $stmt = $pdo->prepare('UPDATE tb_departamentos SET nome = :nome WHERE id_departamentos = :id');
    $stmt->bindParam(':id', $_POST['id']);
    $stmt->bindParam(':nome', $_POST['nome']);

    // Execução da query
    $stmt->execute();

    echo "Departamento atualizado com sucesso!";
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
}
?>
