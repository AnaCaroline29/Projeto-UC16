<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Conexão com o banco de dados
$dsn = 'mysql:host=localhost;dbname=mtech';
$username = 'root';
$password = '';

$id_reservas = isset($_GET['id_reservas']) ? (int)$_GET['id_reservas'] : 0;

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Buscar detalhes da reserva
    $stmt = $pdo->prepare('SELECT * FROM tb_reservas WHERE id_reservas = :id_reservas');
    $stmt->execute(['id_reservas' => $id_reservas]);
    $reserva = $stmt->fetch(PDO::FETCH_ASSOC);

    // Buscar detalhes do usuário
    $stmt = $pdo->prepare('SELECT * FROM tb_usuarios WHERE id_usuarios = :id_usuarios');
    $stmt->execute(['id_usuarios' => $reserva['id_usuarios']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    // Buscar equipamentos da reserva
    $stmt = $pdo->prepare('SELECT * FROM tb_descreservas WHERE id_reservas = :id_reservas');
    $stmt->execute(['id_reservas' => $id_reservas]);
    $equipamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Erro: ' . $e->getMessage();
    exit;
}
?>

<div class="container">
    <h4>1. Dados do Usuário</h4>
    <div class="form-group">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" class="form-control" value="<?= htmlspecialchars($usuario['nome']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" class="form-control" value="<?= htmlspecialchars($usuario['email']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="cpf_cnpj">CPF/CNPJ:</label>
        <input type="text" id="cpf_cnpj" class="form-control" value="<?= htmlspecialchars($usuario['cpf_cnpj']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="logradouro">Logradouro:</label>
        <input type="text" id="logradouro" class="form-control" value="<?= htmlspecialchars($usuario['logradouro']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="numero">Número:</label>
        <input type="text" id="numero" class="form-control" value="<?= htmlspecialchars($usuario['numero']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="bairro">Bairro:</label>
        <input type="text" id="bairro" class="form-control" value="<?= htmlspecialchars($usuario['bairro']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="cep">CEP:</label>
        <input type="text" id="cep" class="form-control" value="<?= htmlspecialchars($usuario['cep']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" class="form-control" value="<?= htmlspecialchars($usuario['telefone']); ?>" readonly>
    </div>

    <h4>2. Requisição de Equipamentos</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Valor Unitário</th>
                <th>Quantidade</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($equipamentos as $equipamento): ?>
                <tr>
                    <td><?= htmlspecialchars($equipamento['id_equipamentos']); ?></td>
                    <td><?= htmlspecialchars($equipamento['nome']); ?></td>
                    <td><?= htmlspecialchars($equipamento['valorunit']); ?></td>
                    <td><?= htmlspecialchars($equipamento['quantidade']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h4>3. Datas</h4>
    <div class="form-group">
        <label for="datareserva">Data de Reserva:</label>
        <input type="text" id="datareserva" class="form-control" value="<?= htmlspecialchars($reserva['datareserva']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="datainiciolocacao">Data de Início da Locação:</label>
        <input type="text" id="datainiciolocacao" class="form-control" value="<?= htmlspecialchars($reserva['datainiciolocacao']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="datafimlocacao">Data de Fim da Locação:</label>
        <input type="text" id="datafimlocacao" class="form-control" value="<?= htmlspecialchars($reserva['datafimlocacao']); ?>" readonly>
    </div>

    <h4>4. Status Solicitação e Proposta de Locação</h4>
    <div class="form-group">
        <label for="status">Status Atual:</label>
        <input type="text" id="status" class="form-control" value="<?= htmlspecialchars($reserva['status']); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="proposta">Proposta de Locação:</label>
        <a href="<?= htmlspecialchars($reserva['proposta']); ?>" target="_blank">Ver Proposta</a>
    </div>
</div>
